
<?php
	$object->name="Andrew";
	$object->age="38";
	$object->phone="647-364-3743";
	$jsonFormat =json_encode($object);
	echo $jsonFormat;
?>

