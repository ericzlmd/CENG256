
function runAjaxScript(){
	var inputField= document.getElementById("name").value ;

	var aj = new XMLHttpRequest();
	aj.onreadystatechange = function(){
		if (this.readyState==4 && this.status==200){
			var resp = this.responseText;
			var recievedObject = JSON.parse(resp);
			var section = document.getElementById("updateArea2");
			var info = recievedObject.lname;
			section.innerHTML=info;	

		}
	};
	var fileName ="getInfo.php?name="+inputField;
	aj.open("GET",fileName,true);
	aj.send();
	return false;
}


function init(){
	var b1 = document.getElementById("subBttn");
	b1.onclick=runAjaxScript;
}

window.onload = init;
