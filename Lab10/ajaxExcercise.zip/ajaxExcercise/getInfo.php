
<?php
	$name = $_GET["name"];
	$db_host="localhost";
        $db_username="testuser";
	$db_passwd="password";
	$obj;
	    
 	$dbc=mysqli_connect('localhost','testuser','password','addressbook')
	 or die ("Could not Connect! \n");

	$sql="SELECT * from Contacts where fname='$name';";

	$result=mysqli_query($dbc,$sql) or die ("Error Querying Database");
	
	while($row=mysqli_fetch_array($result)){
		$obj->lname=$row['lname'];
	}

	 mysqli_close();
	$jsonObj =json_encode($obj);
	echo $jsonObj;

?>
